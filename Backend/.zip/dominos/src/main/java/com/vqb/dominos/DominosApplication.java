package com.vqb.dominos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DominosApplication {

	public static void main(String[] args) {
		SpringApplication.run(DominosApplication.class, args);
	}

}
